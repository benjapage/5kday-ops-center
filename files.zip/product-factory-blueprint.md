# Product Factory — Blueprint Completo

## Contexto del proyecto

**Qué es:** Una aplicación web que automatiza la creación de infoproductos (ebooks, guías, PDFs) para el negocio de Benjamín.

**Problema que resuelve:** Actualmente crear un producto completo (producto principal + 3-5 bonuses) toma un día entero. Con esta app, baja a 15-20 minutos de supervisión.

**Stack:** React + Vite + Supabase + Vercel (mismo stack que el 5KDay Ops Center).

**Integraciones:** Anthropic API (Claude) + Gamma API v1.0.

**Usuario:** Benjamín (único usuario, con potencial de agregar equipo en el futuro).

---

## Flujo principal de la aplicación

```
┌─────────────────────────────────────────────────────────────┐
│                    PRODUCT FACTORY                           │
│                                                              │
│  PASO 1: Elegir marca                                        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐                    │
│  │ Natural  │ │  Salud   │ │ + Nueva  │                    │
│  │ Health   │ │  Total   │ │   marca  │                    │
│  └──────────┘ └──────────┘ └──────────┘                    │
│                                                              │
│  PASO 2: Cargar producto original                            │
│  ┌──────────────────────────────────────────┐               │
│  │  Arrastrá el PDF / pegá el texto         │               │
│  │  Idioma original: [auto-detectar ▼]      │               │
│  └──────────────────────────────────────────┘               │
│                                                              │
│  PASO 3: Configurar salida                                   │
│  Idioma destino: [EN ▼]  [ES ▼]  [PT ▼]                    │
│  Tono: [profesional ▼]                                       │
│  Tema Gamma: [default / personalizado ▼]                     │
│                                                              │
│  PASO 4: Generar                                             │
│  [▶ Generar producto principal]                              │
│  [▶ Generar 3 bonuses]  [▶ Generar 5 bonuses]               │
│                                                              │
│  PASO 5: Resultado                                           │
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐              │
│  │ Prod.  │ │Bonus 1 │ │Bonus 2 │ │Bonus 3 │              │
│  │ princ. │ │ ✓ PDF  │ │ ✓ PDF  │ │ ✓ PDF  │              │
│  │ ✓ PDF  │ │        │ │        │ │        │              │
│  └────────┘ └────────┘ └────────┘ └────────┘              │
│                                                              │
│  [⬇ Descargar paquete completo (.zip)]                      │
└─────────────────────────────────────────────────────────────┘
```

---

## Arquitectura técnica

### Base de datos (Supabase)

**Tabla: brands (marcas)**
```sql
CREATE TABLE brands (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  colors JSONB DEFAULT '{}',
  -- Ejemplo: {"primary": "#2E7D32", "secondary": "#1B5E20", "accent": "#4CAF50"}
  logo_url TEXT,
  tone TEXT DEFAULT 'profesional',
  -- Ejemplo: "profesional", "cercano", "wellness", "urgente"
  target_audience TEXT,
  -- Ejemplo: "Mujer americana, 30-50 años, wellness-minded"
  gamma_theme_id TEXT,
  -- ID del tema en Gamma (se obtiene con GET /v1.0/themes)
  default_language TEXT DEFAULT 'en',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

**Tabla: products (productos generados)**
```sql
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  brand_id UUID REFERENCES brands(id),
  name TEXT NOT NULL,
  original_language TEXT,
  target_language TEXT NOT NULL,
  status TEXT DEFAULT 'draft',
  -- draft | processing | completed | failed
  original_content TEXT,
  -- Texto extraído del PDF/documento original
  translated_content TEXT,
  -- Contenido traducido y adaptado por Claude
  gamma_generation_id TEXT,
  -- ID de la generación en Gamma
  gamma_url TEXT,
  -- URL del documento en Gamma
  pdf_url TEXT,
  -- URL del PDF exportado
  product_type TEXT DEFAULT 'main',
  -- main | bonus
  parent_product_id UUID REFERENCES products(id),
  -- Para bonuses, apunta al producto principal
  bonus_type TEXT,
  -- checklist | guia_rapida | plantilla | workbook | infografia
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

**Tabla: generation_logs (historial de generaciones)**
```sql
CREATE TABLE generation_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id),
  step TEXT NOT NULL,
  -- extract | translate | adapt | gamma_generate | gamma_poll | export
  status TEXT DEFAULT 'pending',
  -- pending | running | completed | failed
  input_preview TEXT,
  output_preview TEXT,
  error_message TEXT,
  credits_used INTEGER,
  duration_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### Flujo técnico detallado

```
USUARIO                    APP (React)                BACKEND (API Routes)
  │                           │                            │
  │  1. Selecciona marca      │                            │
  │  2. Sube PDF/texto        │                            │
  │  3. Elige idioma + config │                            │
  │  4. Click "Generar"       │                            │
  │ ─────────────────────────>│                            │
  │                           │  5. Extrae texto del PDF   │
  │                           │     (si es PDF)            │
  │                           │ ──────────────────────────>│
  │                           │                            │
  │                           │  6. Envía a Claude API     │
  │                           │     para traducir/adaptar  │
  │                           │ ──────────────────────────>│
  │                           │                            │  → Anthropic API
  │                           │                            │    Claude traduce,
  │                           │                            │    adapta tono,
  │                           │                            │    rebrandea
  │                           │                            │  ← Contenido adaptado
  │                           │                            │
  │                           │  7. Envía a Gamma API      │
  │                           │     POST /v1.0/generations │
  │                           │ ──────────────────────────>│
  │                           │                            │  → Gamma API
  │                           │                            │    textMode: preserve
  │                           │                            │    format: document
  │                           │                            │    exportAs: pdf
  │                           │                            │
  │                           │  8. Poll cada 10s          │
  │                           │     GET /generations/{id}  │
  │                           │ ──────────────────────────>│
  │                           │                            │  ← status: completed
  │                           │                            │    gammaUrl + exportUrl
  │                           │                            │
  │  9. Muestra resultado     │                            │
  │  con preview + descarga   │                            │
  │ <─────────────────────────│                            │
```

---

## Integración con Gamma API v1.0

### Autenticación
```
Base URL: https://public-api.gamma.app/v1.0
Header: X-API-KEY: sk-gamma-xxxxxxxx
```

La API key se guarda en las variables de entorno del proyecto en Vercel.

### Endpoint: Generar producto principal (traducido/adaptado)

```javascript
// Producto principal — el contenido ya fue traducido por Claude
const response = await fetch("https://public-api.gamma.app/v1.0/generations", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-API-KEY": process.env.GAMMA_API_KEY
  },
  body: JSON.stringify({
    inputText: contenidoTraducidoPorClaude,
    textMode: "preserve",
    // PRESERVE: mantiene el texto tal cual, solo maquetea
    format: "document",
    // DOCUMENT: formato tipo ebook/revista
    numCards: 15,
    // Cantidad de páginas/secciones (ajustar según el producto)
    cardSplit: "auto",
    themeId: brand.gamma_theme_id || undefined,
    // Tema personalizado de la marca (si existe)
    exportAs: "pdf",
    additionalInstructions: `
      Diseñar como un ebook profesional estilo revista.
      Usar layout limpio y moderno.
      Las imágenes deben ser relevantes al contenido.
      Mantener consistencia visual en todas las páginas.
    `,
    textOptions: {
      language: targetLanguage
      // "en", "es", "pt", etc.
    },
    imageOptions: {
      source: "aiGenerated",
      style: "photorealistic"
    },
    cardOptions: {
      dimensions: "fluid"
    }
  })
});

const { generationId } = await response.json();
```

### Endpoint: Generar bonus (desde cero)

```javascript
// Bonus — Claude genera el contenido completo, Gamma lo maquetea
const response = await fetch("https://public-api.gamma.app/v1.0/generations", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-API-KEY": process.env.GAMMA_API_KEY
  },
  body: JSON.stringify({
    inputText: contenidoBonusGeneradoPorClaude,
    textMode: "preserve",
    format: "document",
    numCards: 8,
    // Bonuses son más cortos
    exportAs: "pdf",
    themeId: brand.gamma_theme_id || undefined,
    additionalInstructions: `
      Diseñar como un bonus/complemento de un producto principal.
      Mantener el mismo estilo visual que el producto principal.
      Formato compacto y directo.
    `,
    textOptions: {
      language: targetLanguage
    },
    imageOptions: {
      source: "aiGenerated",
      style: "photorealistic"
    }
  })
});
```

### Polling del resultado

```javascript
async function pollGeneration(generationId) {
  const maxAttempts = 60; // 10 minutos máximo
  let attempts = 0;

  while (attempts < maxAttempts) {
    const res = await fetch(
      `https://public-api.gamma.app/v1.0/generations/${generationId}`,
      { headers: { "X-API-KEY": process.env.GAMMA_API_KEY } }
    );
    const data = await res.json();

    if (data.status === "completed") {
      return {
        gammaUrl: data.gammaUrl,
        exportUrl: data.exportUrl,
        credits: data.credits
      };
    }

    if (data.status === "failed") {
      throw new Error("Gamma generation failed");
    }

    // Esperar 10 segundos antes de volver a consultar
    await new Promise(resolve => setTimeout(resolve, 10000));
    attempts++;
  }

  throw new Error("Gamma generation timeout");
}
```

### Listar temas disponibles

```javascript
// Para cargar temas en el selector de marca
const res = await fetch("https://public-api.gamma.app/v1.0/themes", {
  headers: { "X-API-KEY": process.env.GAMMA_API_KEY }
});
const { themes } = await res.json();
// themes = [{ id: "Chisel", name: "Chisel", ... }, ...]
```

---

## Integración con Claude API (Anthropic)

### Prompt para traducir y adaptar producto principal

```javascript
const systemPrompt = `
Sos un experto en adaptación de infoproductos digitales.
Tu tarea es tomar un producto (ebook/guía) en un idioma y:

1. Traducirlo al idioma destino de forma natural (no literal)
2. Adaptar el tono al avatar de la marca
3. Reemplazar referencias culturales al mercado destino
4. Mantener la estructura completa del contenido original
5. NO agregar ni quitar secciones — preservar todo

Marca: ${brand.name}
Tono de la marca: ${brand.tone}
Avatar: ${brand.target_audience}
Idioma origen: ${sourceLanguage}
Idioma destino: ${targetLanguage}

Devolvé el contenido completo traducido y adaptado, listo para maquetear.
Usá separadores \n---\n entre secciones/capítulos para que Gamma
pueda dividirlo en páginas correctamente.
`;

const response = await fetch("https://api.anthropic.com/v1/messages", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "x-api-key": process.env.ANTHROPIC_API_KEY,
    "anthropic-version": "2023-06-01"
  },
  body: JSON.stringify({
    model: "claude-sonnet-4-20250514",
    max_tokens: 8000,
    system: systemPrompt,
    messages: [{
      role: "user",
      content: `Adaptá este producto:\n\n${originalContent}`
    }]
  })
});
```

### Prompt para generar bonuses desde cero

```javascript
const bonusSystemPrompt = `
Sos un experto en crear bonuses para infoproductos low ticket.
Tu tarea es crear un bonus complementario al producto principal.

Producto principal: ${mainProduct.name}
Marca: ${brand.name}
Avatar: ${brand.target_audience}
Idioma: ${targetLanguage}
Tipo de bonus: ${bonusType}

Tipos de bonus disponibles:
- checklist: Lista de verificación práctica (10-20 items)
- guia_rapida: Guía de inicio rápido (5-8 páginas)
- plantilla: Plantillas rellenables para el usuario
- workbook: Ejercicios prácticos y hojas de trabajo
- infografia: Datos clave presentados de forma visual

Creá el contenido completo del bonus, listo para maquetear.
Usá separadores \n---\n entre secciones.
El bonus debe complementar al producto principal sin repetir contenido.
Debe ser valioso por sí solo pero dejar claro que el producto principal es el core.
`;
```

---

## Diseño de la interfaz

### Estética
- **Modo:** Dark mode por defecto (consistente con el Ops Center)
- **Estilo:** Moderno, limpio, profesional. NO estilo código/terminal.
- **Tipografía:** Sans-serif moderna (DM Sans, Plus Jakarta Sans, o similar)
- **Colores:** Navy oscuro como base (#0B1A2E), acentos en esmeralda (#10B981) para acciones principales, violeta (#7C3AED) para estados de generación

### Páginas de la app

**1. Dashboard / Home**
- Lista de productos generados recientemente
- Acceso rápido a "Nuevo producto"
- Stats: productos generados este mes, créditos Gamma restantes

**2. Marcas**
- CRUD de marcas con: nombre, colores, logo, tono, avatar, idioma default
- Selector de tema Gamma por marca (se obtienen con GET /v1.0/themes)
- Cada marca es reutilizable en todos los productos

**3. Nuevo producto (wizard de 5 pasos)**
- Paso 1: Seleccionar marca
- Paso 2: Cargar contenido original (PDF upload o texto pegado)
- Paso 3: Configurar (idioma destino, tono, cantidad de bonuses, tipos de bonus)
- Paso 4: Preview del contenido traducido (editable antes de mandar a Gamma)
- Paso 5: Generación (barra de progreso por cada pieza: producto + bonuses)

**4. Detalle de producto**
- Preview del PDF generado
- Links de descarga individual (producto + cada bonus)
- Botón "Descargar paquete completo" (.zip)
- Log de generación (qué pasó en cada step)
- Opción de regenerar individual (si un bonus no quedó bien)

**5. Historial**
- Todos los productos generados, filtrable por marca/idioma/fecha

---

## Variables de entorno (Vercel)

```
GAMMA_API_KEY=sk-gamma-xxxxxxxx
ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJxxx
```

---

## Plan de implementación por fases

### Fase 1 — MVP funcional
1. Setup del proyecto (React + Vite + Supabase + Vercel)
2. CRUD de marcas
3. Flujo de producto principal: subir PDF → Claude traduce → Gamma maquetea → descargar PDF
4. UI básica funcional en dark mode

### Fase 2 — Bonuses y paquetes
5. Generación de bonuses (3-5 por producto)
6. Empaquetado en .zip para descarga
7. Preview de PDFs en la app
8. Historial de productos

### Fase 3 — Optimización
9. Templates/presets de bonuses por nicho
10. Edición del contenido traducido antes de enviar a Gamma
11. Regeneración individual de piezas
12. Integración con el Ops Center (Pipeline: vincular producto con oferta)

---

## Prompt maestro para Claude Code

Pegar esto al iniciar el proyecto en Claude Code:

```
Voy a construir una app web llamada "Product Factory".

STACK:
- React 18 + Vite
- TailwindCSS
- Supabase (auth + base de datos)
- Vercel (deploy)
- Gamma API v1.0 (generación de documentos)
- Anthropic API (traducción/adaptación de contenido)

FUNCIONALIDAD CORE:
La app automatiza la creación de infoproductos (ebooks/guías en PDF).

Flujo principal:
1. Usuario selecciona una marca (con branding, tono, avatar predefinidos)
2. Sube un PDF o pega texto de un producto en otro idioma
3. Elige idioma destino y configuración
4. La app usa la API de Anthropic (Claude) para traducir y adaptar el contenido
5. La app envía el contenido adaptado a la API de Gamma para maquetear como documento PDF
6. La app genera 3-5 bonuses complementarios (Claude genera el contenido, Gamma lo maquetea)
7. El usuario descarga el paquete completo (.zip)

GAMMA API:
- Base URL: https://public-api.gamma.app/v1.0
- Auth: header X-API-KEY (no Bearer)
- Endpoint POST /generations con: inputText, textMode (preserve/generate), format (document), exportAs (pdf)
- Polling: GET /generations/{generationId} cada 10s hasta status "completed"
- Respuesta incluye gammaUrl y exportUrl

ANTHROPIC API:
- Modelo: claude-sonnet-4-20250514
- Para traducción/adaptación y generación de bonuses

DISEÑO:
- Dark mode por defecto
- Estética moderna, limpia, profesional
- NO usar tipografía monospace/código para números
- Colores: navy oscuro (#0B1A2E) como base, esmeralda (#10B981) para CTAs
- Tipografía: sans-serif moderna

BASE DE DATOS (Supabase):
- Tabla brands: id, name, slug, colors (jsonb), logo_url, tone, target_audience, gamma_theme_id, default_language
- Tabla products: id, brand_id (FK), name, original_language, target_language, status, original_content, translated_content, gamma_generation_id, gamma_url, pdf_url, product_type (main/bonus), parent_product_id (FK), bonus_type
- Tabla generation_logs: id, product_id (FK), step, status, input_preview, output_preview, error_message, credits_used, duration_ms

EMPEZAR POR:
Fase 1 — Crear el proyecto, configurar Supabase, hacer el CRUD de marcas, y el flujo básico de generación de un producto principal (sin bonuses todavía).
```

---

## Checklist pre-construcción

Antes de arrancar con Claude Code, Benjamín necesita:

- [ ] **Gamma API Key**: Ir a gamma.app → Settings → API Keys → Crear una key
- [ ] **Anthropic API Key**: Ir a console.anthropic.com → API Keys → Crear una key
- [ ] **Supabase proyecto nuevo**: Crear proyecto en supabase.com → copiar URL + anon key
- [ ] **Vercel**: Tener cuenta lista (misma que usa para el Ops Center)
- [ ] **Opcional**: Crear 2-3 temas personalizados en Gamma para sus marcas principales, y anotar los Theme IDs
